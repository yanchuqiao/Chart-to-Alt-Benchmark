import torch
import json
from PIL import Image
from tqdm import tqdm
from transformers import AutoProcessor, BitsAndBytesConfig, PaliGemmaForConditionalGeneration

# ==== Paths ====
json_path = "/cluster/home/yanc/ChartGemma/test.json"
image_dir = "/cluster/home/yanc/mPLUG-DocOwl/TinyChart-3B/Vistext_data/Chart-to-Alt_All_ThirdFinetune_images"
output_file = "/cluster/home/yanc/ChartGemma/ChartGemma_inference_1prompt.txt"

# ==== Load Model and Processor ====
processor = AutoProcessor.from_pretrained("/cluster/home/yanc/ChartGemma/trained_model/ChartGemma-checkpoint-epoch=2-step=3021")

quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16,
)

model = PaliGemmaForConditionalGeneration.from_pretrained(
    "/cluster/home/yanc/ChartGemma/trained_model/ChartGemma-checkpoint-epoch=2-step=3021",
    torch_dtype=torch.float16,
    quantization_config=quant_config
).to("cuda")
model.eval()

# ==== Load Dataset ====
with open(json_path, "r") as f:
    data = json.load(f)

# ==== Inference ====
with open(output_file, "w") as fout:
    for item in tqdm(data):
        image_id = item["image_id"]
        image_path = f"{image_dir}/{image_id}"
        image = Image.open(image_path).convert("RGB")

        prompt_text = "<image> Generate a caption for the chart"

        inputs = processor(
            text=prompt_text,
            images=[image],
            return_tensors="pt"
        ).to("cuda")
        inputs["pixel_values"] = inputs["pixel_values"].to(torch.float16)

        with torch.no_grad():
            generated_ids = model.generate(
                **inputs, max_new_tokens=128
            )

        prompt_len = inputs["input_ids"].shape[1]
        generated_text = processor.batch_decode(
            generated_ids[:, prompt_len:], skip_special_tokens=True
        )[0].strip()

        fout.write(f"Generated text for image {image_id}: {generated_text}\n")

