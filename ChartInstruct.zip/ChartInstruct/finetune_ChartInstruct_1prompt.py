import os
import json
import random
import torch
import numpy as np
from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from transformers import AutoProcessor, LlavaForConditionalGeneration, BitsAndBytesConfig
from peft import LoraConfig, prepare_model_for_kbit_training, get_peft_model
from pytorch_lightning.utilities import rank_zero_only
import lightning as L
from pytorch_lightning.loggers import WandbLogger
from lightning.pytorch.callbacks import ModelCheckpoint

# === Configuration ===
train_json = "/cluster/home/yanc/Chart-to-Alt_Dataset/train.json"
val_json = "/cluster/home/yanc/Chart-to-Alt_Dataset/val.json"
image_dir = "/cluster/home/yanc/Chart-to-Alt_Dataset/Chart-to-Alt_All_ThirdFinetune_images"
checkpoint_dir = Path("trained_model/1prompt")

config = {
    "use_lora": True,
    "use_qlora": False,
    "max_epochs": 5,
    "batch_size": 4,
    "lr": 1e-4,
    "accumulate_grad_batches": 8,
    "check_val_every_n_epoch": 1,
    "gradient_clip_val": 1.0,
    "result_path": "trained_model/1prompt",
    "verbose": True,
}

# === Dataset ===
class ChartToAltDataset(Dataset):
    def __init__(self, json_path: str, image_dir: str):
        self.image_dir = image_dir
        with open(json_path, "r") as f:
            raw_data = json.load(f)

        self.data = []
        for item in raw_data:
            self.data.append({
                "image_id": item["image_id"],
                "prompt": "<image>\nQuestion: Provide textual summaries for the chart. Answer:",
                "label": f"{item['caption_L1']} {item['caption_L2L3']}"
            })

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample = self.data[idx]
        image_path = os.path.join(self.image_dir, sample["image_id"])
        image = Image.open(image_path).convert("RGB")
        return image, f"{sample['prompt']} {sample['label']}"


train_dataset = ChartToAltDataset(train_json, image_dir)
val_dataset = ChartToAltDataset(val_json, image_dir)

# === Collate Function ===
processor = AutoProcessor.from_pretrained("ahmed-masry/ChartInstruct-LLama2")

def collate_fn(examples):
    images, texts = zip(*examples)
    batch = processor(text=texts, images=images, padding=True, truncation=True, max_length=128, return_tensors="pt")
    labels = batch["input_ids"].clone()
    labels[labels == processor.tokenizer.pad_token_id] = -100
    return batch["input_ids"], batch["attention_mask"], batch["pixel_values"], labels

# === Load Model ===
if config["use_qlora"]:
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16
    )
    model = LlavaForConditionalGeneration.from_pretrained(
        "ahmed-masry/ChartInstruct-LLama2",
        torch_dtype=torch.float16,
        quantization_config=bnb_config,
    )
else:
    model = LlavaForConditionalGeneration.from_pretrained(
        "ahmed-masry/ChartInstruct-LLama2",
        torch_dtype=torch.float16,
    )

# === Apply LoRA if needed ===
def find_all_linear_names(model):
    cls = torch.nn.Linear
    skip_keywords = ['multi_modal_projector', 'vision_model']
    lora_names = set()
    for name, module in model.named_modules():
        if any(k in name for k in skip_keywords):
            continue
        if isinstance(module, cls):
            lora_names.add(name.split('.')[-1])
    lora_names.discard('lm_head')
    return list(lora_names)

lora_config = LoraConfig(
    r=8,
    lora_alpha=8,
    lora_dropout=0.1,
    target_modules=find_all_linear_names(model),
    init_lora_weights="gaussian"
)

model = prepare_model_for_kbit_training(model)
model = get_peft_model(model, lora_config)

# === Lightning Module ===
class LlavaModelPLModule(L.LightningModule):
    def __init__(self, config, processor, model):
        super().__init__()
        self.config = config
        self.processor = processor
        self.model = model

    def training_step(self, batch, batch_idx):
        input_ids, attention_mask, pixel_values, labels = batch
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values,
            labels=labels
        )
        self.log("train_loss", outputs.loss, on_epoch=True, prog_bar=True, logger=True)
        return outputs.loss

    def validation_step(self, batch, batch_idx):
        input_ids, attention_mask, pixel_values, labels = batch
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values,
            labels=labels
        )
        self.log("val_loss", outputs.loss, on_epoch=True, prog_bar=True, logger=True)
        return outputs.loss

    def configure_optimizers(self):
        return torch.optim.AdamW(self.parameters(), lr=self.config["lr"])

    def train_dataloader(self):
        return DataLoader(train_dataset, collate_fn=collate_fn, batch_size=config["batch_size"], shuffle=True, num_workers=8)

    def val_dataloader(self):
        return DataLoader(val_dataset, collate_fn=collate_fn, batch_size=config["batch_size"], shuffle=False, num_workers=8)

    @rank_zero_only
    def on_save_checkpoint(self, checkpoint):
        save_path = os.path.join(
            self.config['result_path'], 
            f'ChartInstruct-1prompt-epoch={self.current_epoch}'
        )
        self.model.save_pretrained(save_path)
        self.processor.save_pretrained(save_path)
# === Training ===
wandb_logger = WandbLogger(project="ChartInstruct")
model_module = LlavaModelPLModule(config, processor, model)

checkpoint_callback = ModelCheckpoint(
    dirpath=str(checkpoint_dir),
    filename="checkpoint-{epoch}",
    save_top_k=-1,
    save_weights_only=False,
    every_n_epochs=1
)

resume_path = checkpoint_dir / "last.ckpt"
resume_kwargs = {"resume_from_checkpoint": str(resume_path)} if resume_path.exists() else {}

trainer = L.Trainer(
    accelerator="gpu",
    devices=[0],
    max_epochs=config["max_epochs"],
    accumulate_grad_batches=config["accumulate_grad_batches"],
    check_val_every_n_epoch=config["check_val_every_n_epoch"],
    gradient_clip_val=config["gradient_clip_val"],
    precision="16-mixed",
    num_sanity_val_steps=0,
    callbacks=[checkpoint_callback],
    logger=wandb_logger,
    default_root_dir=str(checkpoint_dir),
    **resume_kwargs
)

trainer.fit(model_module)