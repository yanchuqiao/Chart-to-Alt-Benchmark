import torch
import json
from PIL import Image
from tqdm import tqdm
from transformers import AutoProcessor, BitsAndBytesConfig, LlavaForConditionalGeneration

# ==== Paths ====
json_path = "/cluster/home/yanc/Chart-to-Alt_Dataset/test.json"
image_dir = "/cluster/home/yanc/Chart-to-Alt_Dataset/Chart-to-Alt_All_ThirdFinetune_images"
output_file = "/cluster/home/yanc/ChartIntruct/ChartInstruct_inference_1prompt.txt"
model_path = "/cluster/home/yanc/ChartIntruct/trained_model/1prompt/ChartInstruct-1prompt-epoch=2"

# ==== Load Processor ====
processor = AutoProcessor.from_pretrained(model_path)

# ==== Load Model ====
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16
)

model = LlavaForConditionalGeneration.from_pretrained(
    model_path,
    torch_dtype=torch.float16,
    quantization_config=quant_config
).to("cuda")
model.eval()

# ==== Prompt ====
prompt = "<image>\nQuestion: Provide textual summaries for the chart. Answer:"

# ==== Load Dataset ====
with open(json_path, "r") as f:
    data = json.load(f)

# ==== Inference ====
with open(output_file, "w") as fout:
    for item in tqdm(data):
        image_id = item["image_id"]
        image_path = f"{image_dir}/{image_id}"
        image = Image.open(image_path).convert("RGB")

        inputs = processor(
            text=prompt,
            images=[image],
            return_tensors="pt"
        ).to("cuda")
        inputs["pixel_values"] = inputs["pixel_values"].to(torch.float16)

        with torch.no_grad():
            generated_ids = model.generate(
                **inputs,
                max_new_tokens=128
            )

        prompt_len = inputs["input_ids"].shape[1]
        generated_text = processor.batch_decode(
            generated_ids[:, prompt_len:], skip_special_tokens=True
        )[0].strip()

        fout.write(f"Generated text for image {image_id}: {generated_text}\n")
