from transformers import (
    VisionEncoderDecoderModel,
    DonutProcessor
)
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import DataLoader, Dataset
import torch
from PIL import Image
import os
import json
import argparse
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint, Callback
import shutil
import math
from torch.optim.lr_scheduler import LambdaLR
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pdb
from pytorch_lightning.utilities import rank_zero_only

class VisTextDataset(Dataset):
    def __init__(
        self,
        dataset: str,
        images_folder: str,
        max_length: int,
        processor : DonutProcessor,
        split: str = "train",
        ignore_id: int = -100,
        prompt_end_token: str = "<s_answer>",
        task_prefix_L1: str = '<summarize_chart_to_L1_caption>',
        task_prefix_L2L3: str = '<summarize_chart_to_L2L3_caption>',
        sort_json_key: bool = True,
    ):
        super().__init__()

        self.max_length = max_length
        self.split = split
        self.ignore_id = ignore_id

        self.prompt_end_token = prompt_end_token 
        self.sort_json_key = sort_json_key
        self.images_folder = images_folder

  
        self.dataset = dataset
        self.dataset_length = len(self.dataset)

        self.processor = processor
        self.prompt_end_token_id = self.processor.tokenizer.convert_tokens_to_ids(self.prompt_end_token)
        self.task_prefix_L1 = task_prefix_L1
        self.task_prefix_L2L3 = task_prefix_L2L3
        # Load examples
        self.examples = self._load_examples()

    def _load_examples(self):
        examples = []
        with open(self.dataset, 'r') as f:
            data = json.load(f)
            for entry in data:
                l1_caption = entry['caption_L1']
                l2l3_caption = entry['caption_L2L3']
                examples.append({
                    'image_id': entry['image_id'],
                    'caption_L1': l1_caption,
                    'caption_L2L3': l2l3_caption
                })
        return examples

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        example = self.examples[idx]
        image_path = os.path.join("/cluster/home/yanc/Unichart/Chart-to-Alt_All_ThirdFinetune_images", f"{example['image_id']}")
        image = Image.open(image_path)
        pixel_values = self.processor(image.convert("RGB"), return_tensors="pt").pixel_values
        input_tensor = pixel_values.squeeze()
        #combined_caption = f"{example['caption_L1']} {example['caption_L2L3']}"
        #processed_caption = f"{self.task_prefix} {combined_caption}" #if self.task_prefix else combined_caption
        #processed_caption += self.processor.tokenizer.eos_token
        #level1 caption
        processed_caption_L1 = f"{self.task_prefix_L1}{self.prompt_end_token} {example['caption_L1']}"
        processed_caption_L1 += self.processor.tokenizer.eos_token
        input_ids_L1 = self.processor.tokenizer(
            processed_caption_L1,
            add_special_tokens=False,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )["input_ids"].squeeze(0)

        # Level 2 Caption
        processed_caption_L2L3 = f"{self.task_prefix_L2L3}{self.prompt_end_token} {example['caption_L2L3']}"
        processed_caption_L2L3 += self.processor.tokenizer.eos_token
        input_ids_L2L3 = self.processor.tokenizer(
            processed_caption_L2L3,
            add_special_tokens=False,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )["input_ids"].squeeze(0)
        if self.split == "train":
            labels_L1 = input_ids_L1.clone()
            labels_L2L3 = input_ids_L2L3.clone()

            labels_L1[labels_L1 == self.processor.tokenizer.pad_token_id] = self.ignore_id
            labels_L2L3[labels_L2L3 == self.processor.tokenizer.pad_token_id] = self.ignore_id # model doesn't need to predict pad token
            
            labels_L1[: torch.nonzero(labels_L1 == self.prompt_end_token_id).sum() + 1] = self.ignore_id
            labels_L2L3[: torch.nonzero(labels_L2L3 == self.prompt_end_token_id).sum() + 1] = self.ignore_id  # model doesn't need to predict prompt 
            return input_tensor, (input_ids_L1, input_ids_L2L3), (labels_L1, labels_L2L3)
        else:
            labels_L1 = input_ids_L1.clone()
            labels_L2L3 = input_ids_L2L3.clone()

            labels_L1[labels_L1 == self.processor.tokenizer.pad_token_id] = self.ignore_id
            labels_L2L3[labels_L2L3 == self.processor.tokenizer.pad_token_id] = self.ignore_id # model doesn't need to predict pad token
            
            labels_L1[: torch.nonzero(labels_L1 == self.prompt_end_token_id).sum() + 1] = self.ignore_id
            labels_L2L3[: torch.nonzero(labels_L2L3 == self.prompt_end_token_id).sum() + 1] = self.ignore_id

            prompt_end_index_L1 = torch.nonzero(
                input_ids_L1 == self.prompt_end_token_id
            ).sum()
            prompt_end_index_L2L3 = torch.nonzero(
                input_ids_L2L3 == self.prompt_end_token_id).sum()  # Prompt end index for L2L3  # return prompt end index instead of target output labels
            return input_tensor, (input_ids_L1, input_ids_L2L3), (prompt_end_index_L1, prompt_end_index_L2L3), (labels_L1, labels_L2L3), (processed_caption_L1, processed_caption_L2L3)


class VisTextModule(pl.LightningModule):
    def __init__(self, config, processor, model, args, train_dataset, val_dataset):
        super().__init__()
        self.config = config
        self.processor = processor
        self.model = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.args = args

        self.answer_separator_token = "<sep>"
        self.answer_separator_token_id = self.processor.tokenizer.convert_tokens_to_ids(self.answer_separator_token)

        self.vectorizer = TfidfVectorizer()

    def training_step(self, batch, batch_idx):
        #pixel_values, decoder_input_ids, labels = batch 
        pixel_values, input_ids_tuple, labels_tuple = batch
        losses = []
        for input_ids, labels in zip(input_ids_tuple, labels_tuple):
            outputs = self.model(pixel_values,
                                 decoder_input_ids=input_ids[:, :-1],
                                 labels=labels[:, 1:])
            loss = outputs.loss
            losses.append(loss)
        total_loss = torch.stack(losses).mean()
        self.log("train_loss", total_loss, on_step=True, on_epoch=True, logger=True)
        return total_loss
        
    def compute_metric(self, gt, pred):
        try:
            # Tokenize and vectorize the ground truth and predicted texts
            gt_vector = self.vectorizer.fit_transform([gt])
            pred_vector = self.vectorizer.transform([pred])

            similarity = cosine_similarity(gt_vector, pred_vector)
            threshold = 0.7  
            return similarity[0][0] >= threshold
        except Exception as e:
            print("Exception occurred during metric calculation:", e)
            return False

    # def validation_step(self, batch, batch_idx, dataset_idx=0):
    #     pixel_values, input_ids_tuple, prompt_end_idxs_tuple, captions_tuple = batch
    #     predictions = []
    #     targets = []
    #     scores_list = []
    #     for input_ids, prompt_end_idx, captions in zip(input_ids_tuple, prompt_end_idxs_tuple, captions_tuple):
    #         decoder_prompts = pad_sequence(
    #             [input_id[: end_idx + 1] for input_id, end_idx in zip(input_ids, prompt_end_idx)],
    #             batch_first=True,
    #         )

    #         outputs = self.model.generate(
    #             pixel_values,
    #             decoder_input_ids=decoder_prompts,
    #             max_length=self.args.max_length,
    #             early_stopping=True,
    #             pad_token_id=self.processor.tokenizer.pad_token_id,
    #             eos_token_id=self.processor.tokenizer.eos_token_id,
    #             use_cache=True,
    #             num_beams=4,
    #             length_penalty=0.8,
    #             bad_words_ids=[[self.processor.tokenizer.unk_token_id]],
    #             return_dict_in_generate=True
    #         )
    #         seq = self.processor.tokenizer.batch_decode(outputs.sequences)[0]  # Assuming there's only one generated sequence
    #         seq = seq.replace(self.processor.tokenizer.eos_token, "").replace(self.processor.tokenizer.pad_token, "")

    #         #print("seq:", seq)
    #         # print(type(seq))
    #         predictions.append(seq)
    #         targets.extend(captions)

    #         if len(predictions) == 2:
    #             print("predictions:", predictions)
    #             print("targets:", targets)
    #             scores = []
                
    #             for pred, target in zip(predictions, targets):
    #                 print('pred', pred)
    #                 print('target', target)
    #                 pred = pred.split("<s_answer>")[1]
    #                 target = target.split("<s_answer>")[1].replace("</s>", "")
    #                 print('split pred', pred)
    #                 print('split target', target)
    #                 # if "<summarize_chart_to_L1_caption>" in target:
    #                 #     target = target.replace("<summarize_chart_to_L1_caption>", "")
    #                 # elif "<summarize_chart_to_L2L3_caption>" in target:
    #                 #     target = target.replace("<summarize_chart_to_L2L3_caption>", "").replace("</s>", "")
    #                 if self.compute_metric(target, pred):
    #                     scores.append(1)
    #                 else:
    #                     scores.append(0)
    #             # Reset predictions and targets for the next pair
    #             print("scores for each image: ", scores)
    #             scores_list.extend(scores)
    #             predictions = []
    #             targets = []
    #     return scores_list
    def validation_step(self, batch, batch_idx, dataset_idx=0):
        pixel_values, input_ids_tuple, prompt_end_idxs_tuple,label_tuple, captions_tuple = batch
        predictions = []
        targets = []
        scores_list = []
        val_losses = []
        for input_ids, prompt_end_idx, label, captions in zip(input_ids_tuple, prompt_end_idxs_tuple,label_tuple, captions_tuple):
            decoder_prompts = pad_sequence(
                [input_id[: end_idx + 1] for input_id, end_idx in zip(input_ids, prompt_end_idx)],
                batch_first=True,
            )

            outputs = self.model.generate(
                pixel_values,
                decoder_input_ids=decoder_prompts,
                max_length=self.args.max_length,
                early_stopping=True,
                pad_token_id=self.processor.tokenizer.pad_token_id,
                eos_token_id=self.processor.tokenizer.eos_token_id,
                use_cache=True,
                num_beams=4,
                length_penalty=0.8,
                bad_words_ids=[[self.processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True
            )
            seq = self.processor.tokenizer.batch_decode(outputs.sequences)[0]
            seq = seq.replace(self.processor.tokenizer.eos_token, "").replace(self.processor.tokenizer.pad_token, "")

            predictions.append(seq)
            targets.extend(captions)

            val_outputs = self.model(pixel_values, decoder_input_ids=input_ids[:, :-1], labels=label[:, 1:])
            val_loss = val_outputs.loss
            val_losses.append(val_loss)
            self.log("val_loss", val_loss, on_epoch=True, prog_bar=True, logger=True, batch_size=self.args.valid_batch_size)


            if len(predictions) == 2:
                scores = []
                for pred, target in zip(predictions, targets):
                    print("zipping pred: ", pred)
                    print("zipping target: ", target)
                    pred = pred.split("<s_answer>")[1]
                    target = target.split("<s_answer>")[1].replace("</s>", "")
                    if self.compute_metric(target, pred):
                        scores.append(1)
                    else:
                        scores.append(0)
                scores_list.extend(scores)
                predictions = []
                targets = []

        return {"scores": scores_list, "val_loss": torch.stack(val_losses).mean()}


    # def validation_epoch_end(self, validation_step_outputs):
    #     print("validation_step_outputs: ", validation_step_outputs)

    #     num_of_loaders = 1
    #     if num_of_loaders == 1:
    #         validation_step_outputs = [validation_step_outputs]
    #     assert len(validation_step_outputs) == num_of_loaders
    #     cnt = [0] * num_of_loaders
    #     total_metric = [0] * num_of_loaders
    #     val_metric = [0] * num_of_loaders
    #     for i, results in enumerate(validation_step_outputs):
    #         for scores in results:
    #             cnt[i] += len(scores)
    #             total_metric[i] += np.sum(scores)
    #         val_metric[i] = total_metric[i] / cnt[i]
    #         val_metric_name = f"val_metric_{i}th_dataset"
    #         self.log_dict({val_metric_name: val_metric[i]}, sync_dist=True)
    #     self.log_dict({"val_metric": np.sum(total_metric) / np.sum(cnt)}, sync_dist=True)
    #     print(f"Epoch: {self.current_epoch}, Step: {self.global_step}, Validation Metric: {np.sum(total_metric) / np.sum(cnt):.4f}")
    def validation_epoch_end(self, validation_step_outputs):
        print("validation_step_outputs: ", validation_step_outputs)
        scores_list = [x["scores"] for x in validation_step_outputs]
        val_losses = [x["val_loss"] for x in validation_step_outputs]
        avg_val_loss = torch.stack(val_losses).mean()
        self.log("val_loss", avg_val_loss, on_epoch=True, logger=True, batch_size=self.args.valid_batch_size)

        num_of_loaders = 1
        if num_of_loaders == 1:
            scores_list = [scores_list]
        assert len(scores_list) == num_of_loaders
        cnt = [0] * num_of_loaders
        total_metric = [0] * num_of_loaders
        val_metric = [0] * num_of_loaders
        for i, results in enumerate(scores_list):
            for scores in results:
                cnt[i] += len(scores)
                total_metric[i] += np.sum(scores)
            val_metric[i] = total_metric[i] / cnt[i]
            val_metric_name = f"val_metric_{i}th_dataset"
            self.log_dict({val_metric_name: val_metric[i]}, sync_dist=True)
        self.log_dict({"val_metric": np.sum(total_metric) / np.sum(cnt)}, sync_dist=True)
        print(f"Epoch: {self.current_epoch}, Step: {self.global_step}, Validation Metric: {np.sum(total_metric) / np.sum(cnt):.4f}")

    def configure_optimizers(self):
        max_iter = None

        if int(self.config.get("max_epochs", -1)) > 0:
            assert len(self.config.get("train_batch_sizes")) == 1, "Set max_epochs only if the number of datasets is 1"
            max_iter = (self.config.get("max_epochs") * self.config.get("num_training_samples_per_epoch")) / (
                self.config.get("train_batch_sizes")[0] * torch.cuda.device_count() * self.config.get("num_nodes", 1)
            )

        if int(self.config.get("max_steps", -1)) > 0:
            max_iter = min(self.config.get("max_steps"), max_iter) if max_iter is not None else self.config.get("max_steps")

        assert max_iter is not None
        optimizer = torch.optim.Adam(self.parameters(), lr=self.config.get("lr"))
        scheduler = {
            "scheduler": self.cosine_scheduler(optimizer, max_iter, self.config.get("warmup_steps")),
            "name": "learning_rate",
            "interval": "step",
        }
        return [optimizer], [scheduler]

    @staticmethod
    def cosine_scheduler(optimizer, training_steps, warmup_steps):
        def lr_lambda(current_step):
            if current_step < warmup_steps:
                return current_step / max(1, warmup_steps)
            progress = current_step - warmup_steps
            progress /= max(1, training_steps - warmup_steps)
            return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

        return LambdaLR(optimizer, lr_lambda)

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.args.batch_size, shuffle=True, num_workers=self.args.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.args.valid_batch_size, shuffle=False, num_workers=self.args.num_workers)
    
    @rank_zero_only
    def on_save_checkpoint(self, checkpoint):
        save_path = os.path.join(self.config['result_path'], 'vistext-checkpoint-epoch='+str(self.current_epoch)+'-'+str(self.global_step))
        self.model.save_pretrained(save_path)
        self.processor.save_pretrained(save_path)

def main():
    parser = argparse.ArgumentParser(description='Fine-tune Vision Encoder Decoder model on VisText dataset')
    parser.add_argument('--train-data-path', type=str, default="/cluster/home/yanc/Unichart/train.json", help='Path to the train.json file')
    parser.add_argument('--valid-data-path', type=str, default="/cluster/home/yanc/Unichart/val.json", help='Path to the valid.json file')
    parser.add_argument('--images-folder', type=str, default="/cluster/home/yanc/Unichart/Chart-to-Alt_All_ThirdFinetune_images", help='Path to the folder containing chart images')
    parser.add_argument('--output_dir', type=str, default="/cluster/home/yanc/Unichart/Finetuning_Chart-to-Alt", help='Path to the output directory for saving the checkpoints')
    parser.add_argument('--max_steps', type=int, default=2, help='Max number of training steps')
    parser.add_argument('--batch-size', type=int, default=4, help='Batch Size for training')
    parser.add_argument('--valid-batch-size', type=int, default=4, help='Batch Size for validation')
    parser.add_argument('--max-length', type=int, default=512, help='Max length for decoder generation')
    parser.add_argument('--lr', type=float, default=5e-5, help='Learning rate')
    parser.add_argument('--gpus-num', type=int, default=1, help='Number of GPUs to use')
    parser.add_argument('--num-workers', type=int, default=8, help='Number of workers for DataLoader')
    parser.add_argument('--ckpt-file', type=str, default="ahmed-masry/unichart-base-960", help='Path to the checkpoint file (.ckpt)')
    parser.add_argument('--checkpoint_path', type=str, default = "ahmed-masry/unichart-base-960", help='Path to the checkpoint')
    parser.add_argument('--check-val-every-n-epoch', type=int, default=1, help='Run validation every n epochs')
    parser.add_argument('--log-every-n-steps', type=int, default=500, help='Log every n steps')
    parser.add_argument('--warmup_steps', type=int, default=500, help='Warmup steps')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    processor = DonutProcessor.from_pretrained(args.checkpoint_path)
    model = VisionEncoderDecoderModel.from_pretrained(args.checkpoint_path)

    train_data_path = "/cluster/home/yanc/Unichart/train.json"
    valid_data_path = "/cluster/home/yanc/Unichart/val.json"

    train_dataset = VisTextDataset(train_data_path, args.images_folder, args.max_length, processor, split="train")
    print(len(train_dataset))
    #train_dataloader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)

    valid_dataset = VisTextDataset(valid_data_path, args.images_folder, args.max_length, processor, split="valid")
    print(len(valid_dataset))
    #valid_dataloader = DataLoader(valid_dataset, batch_size=args.valid_batch_size, shuffle=False, num_workers=args.num_workers)
    wandb_logger = WandbLogger(project="UniChart")

    config = {
        "max_steps": args.max_steps,
        "check_val_every_n_epoch": args.check_val_every_n_epoch,
        "log_every_n_steps": args.log_every_n_steps,
        "lr": args.lr,
        "batch_size": args.batch_size,
        "valid_batch_size": args.valid_batch_size,
        "warmup_steps": args.warmup_steps,
        "result_path": args.output_dir
    }
    model_module = VisTextModule(config, processor, model, args, train_dataset, valid_dataset).to(device)
    checkpoint_callback = ModelCheckpoint(dirpath=args.output_dir, save_last = True, save_top_k = -1)
    
    callbacks = [checkpoint_callback] #SaveAdditionalFiles(args.output_dir) 

    if os.path.exists(args.output_dir):
        trainer = pl.Trainer(
            resume_from_checkpoint=os.path.join(args.output_dir, 'last.ckpt'),
            accelerator="gpu",
            devices=args.gpus_num,
            max_epochs=5,
            log_every_n_steps=args.log_every_n_steps,
            gradient_clip_val=1.0,
            num_sanity_val_steps=0,
            default_root_dir=args.output_dir,
            callbacks=callbacks,
            logger=wandb_logger,
        )
    else:
        trainer = pl.Trainer(
            accelerator="gpu",
            devices=args.gpus_num,
            max_epochs=5,
            log_every_n_steps=args.log_every_n_steps,
            gradient_clip_val=1.0,
            num_sanity_val_steps=0,
            default_root_dir=args.output_dir,
            callbacks=callbacks,
            logger=wandb_logger
        )

    trainer.fit(model_module)

if __name__ == '__main__':
    main()
