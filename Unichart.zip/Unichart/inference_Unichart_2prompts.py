from transformers import DonutProcessor, VisionEncoderDecoderModel
from PIL import Image
import torch
import json
import os
import pdb

model_name = "/cluster/home/yanc/Unichart/Finetuning_Chart-to-Alt/vistext-checkpoint-epoch=4-10065"
model = VisionEncoderDecoderModel.from_pretrained(model_name)
processor = DonutProcessor.from_pretrained(model_name)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
#pdb.set_trace()

image_folder = "/cluster/home/yanc/Unichart/Chart-to-Alt_All_ThirdFinetune_images"
output_file = "/cluster/home/yanc/Unichart/inference_Unichart_v2.txt"
test_data_path = "/cluster/home/yanc/Unichart/test.json"

with open(test_data_path, "r") as f:
    test_data = json.load(f)

with open(output_file, "w") as f:
    for item in test_data:
        img_id = item['image_id']
        image_path = os.path.join(image_folder, f"{img_id}")
        
        if os.path.exists(image_path):
            image = Image.open(image_path).convert("RGB")

            pixel_values = processor(image, return_tensors="pt").pixel_values

            input_prompt_L1 = "<summarize_chart_to_L1_caption><s_answer>"
            decoder_input_ids_L1 = processor.tokenizer(input_prompt_L1, add_special_tokens=False, return_tensors="pt").input_ids

            outputs_L1 = model.generate(
                pixel_values.to(device),
                decoder_input_ids=decoder_input_ids_L1.to(device),
                max_length=model.config.decoder.max_length,
                early_stopping=True,
                pad_token_id=processor.tokenizer.pad_token_id,
                eos_token_id=processor.tokenizer.eos_token_id,
                use_cache=True,
                num_beams=4,
                bad_words_ids=[[processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True,
            )

            generated_sequence_L1 = processor.tokenizer.decode(outputs_L1.sequences[0], skip_special_tokens=True)
            generated_sequence_L1 = generated_sequence_L1.split('<s_answer> ')[1]

            input_prompt_L2L3 = "<summarize_chart_to_L2L3_caption><s_answer>"
            decoder_input_ids_L2L3 = processor.tokenizer(input_prompt_L2L3, add_special_tokens=False, return_tensors="pt").input_ids

            outputs_L2L3 = model.generate(
                pixel_values.to(device),
                decoder_input_ids=decoder_input_ids_L2L3.to(device),
                max_length=model.config.decoder.max_length,
                early_stopping=True,
                pad_token_id=processor.tokenizer.pad_token_id,
                eos_token_id=processor.tokenizer.eos_token_id,
                use_cache=True,
                num_beams=4,
                bad_words_ids=[[processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True,
            )
            generated_sequence_L2L3 = processor.tokenizer.decode(outputs_L2L3.sequences[0], skip_special_tokens=True)
            generated_sequence_L2L3 = generated_sequence_L2L3.split('<s_answer> ')[1]

            f.write(f"Generated text for image {img_id} (caption_L1): {generated_sequence_L1}\n")
            f.write(f"Generated text for image {img_id} (caption_L2L3): {generated_sequence_L2L3}\n")
        else:
            print(f"Image {image_path} not found.")
print("Generated summaries have been saved to", output_file)
