from transformers import (
    VisionEncoderDecoderModel,
    DonutProcessor
)
from pytorch_lightning.loggers import WandbLogger
from torch.utils.data import DataLoader, Dataset
import torch
from PIL import Image
import os
import json
import argparse
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint
import math
from torch.optim.lr_scheduler import LambdaLR
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from pytorch_lightning.utilities import rank_zero_only
import pdb

class VisTextDataset(Dataset):
    def __init__(
        self,
        dataset: str,
        images_folder: str,
        max_length: int,
        processor : DonutProcessor,
        split: str = "train",
        ignore_id: int = -100,
        prompt_end_token: str = "<s_answer>",
        task_prefix: str = '<summarize_chart>',
        sort_json_key: bool = True,
    ):
        super().__init__()

        self.max_length = max_length
        self.split = split
        self.ignore_id = ignore_id

        self.prompt_end_token = prompt_end_token 
        self.sort_json_key = sort_json_key
        self.images_folder = images_folder

        self.dataset = dataset
        self.dataset_length = len(self.dataset)

        self.processor = processor
        self.prompt_end_token_id = self.processor.tokenizer.convert_tokens_to_ids(self.prompt_end_token)
        self.task_prefix = task_prefix
        # Load examples
        self.examples = self._load_examples()

    def _load_examples(self):
        examples = []
        with open(self.dataset, 'r') as f:
            data = json.load(f)
            for entry in data:
                l1_caption = entry['caption_L1']
                l2l3_caption = entry['caption_L2L3']
                examples.append({
                    'image_id': entry['image_id'],
                    'caption_L1': l1_caption,
                    'caption_L2L3': l2l3_caption
                })
        return examples

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        example = self.examples[idx]
        image_path = os.path.join(self.images_folder, f"{example['image_id']}.png")
        image = Image.open(image_path)
        pixel_values = self.processor(image.convert("RGB"), return_tensors="pt").pixel_values
        input_tensor = pixel_values.squeeze()

        # Combine captions with the specified tokens
        combined_caption = f"<L1_caption>{example['caption_L1']} <L2L3_caption>{example['caption_L2L3']}"
        processed_caption = f"{self.task_prefix}{self.prompt_end_token} {combined_caption}{self.processor.tokenizer.eos_token}"

        input_ids = self.processor.tokenizer(
            processed_caption,
            add_special_tokens=False,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )["input_ids"].squeeze(0)

        if self.split == "train":
            labels = input_ids.clone()
            labels[labels == self.processor.tokenizer.pad_token_id] = self.ignore_id
            labels[: torch.nonzero(labels == self.prompt_end_token_id).sum() + 1] = self.ignore_id
            return input_tensor, input_ids, labels
        else:
            labels = input_ids.clone()
            labels[labels == self.processor.tokenizer.pad_token_id] = self.ignore_id
            labels[: torch.nonzero(labels == self.prompt_end_token_id).sum() + 1] = self.ignore_id

            prompt_end_index = torch.nonzero(
                input_ids == self.prompt_end_token_id
            ).sum()
            return input_tensor, input_ids, prompt_end_index, labels, processed_caption



class VisTextModule(pl.LightningModule):
    def __init__(self, config, processor, model, args, train_dataset, val_dataset):
        super().__init__()
        self.config = config
        self.processor = processor
        self.model = model
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.args = args

        self.answer_separator_token = "<sep>"
        self.answer_separator_token_id = self.processor.tokenizer.convert_tokens_to_ids(self.answer_separator_token)

        self.vectorizer = TfidfVectorizer()

    def training_step(self, batch, batch_idx):
        pixel_values, input_ids, labels = batch
        outputs = self.model(pixel_values,
                             decoder_input_ids=input_ids[:, :-1],
                             labels=labels[:, 1:])
        loss = outputs.loss
        self.log("train_loss", loss, on_step=True, on_epoch=True, logger=True)
        return loss
        
    def compute_metric(self, gt, pred):
        try:
            gt_vector = self.vectorizer.fit_transform([gt])
            pred_vector = self.vectorizer.transform([pred])

            similarity = cosine_similarity(gt_vector, pred_vector)
            threshold = 0.7  
            return similarity[0][0] >= threshold
        except Exception as e:
            print("Exception occurred during metric calculation:", e)
            return False

    def validation_step(self, batch, batch_idx, dataset_idx=0):
        pixel_values, input_ids, prompt_end_idx, labels, caption = batch
        decoder_prompts = pad_sequence(
            [input_id[: end_idx + 1] for input_id, end_idx in zip(input_ids, prompt_end_idx)],
            batch_first=True,
        )

        outputs = self.model.generate(
            pixel_values,
            decoder_input_ids=decoder_prompts,
            max_length=self.args.max_length,
            early_stopping=True,
            pad_token_id=self.processor.tokenizer.pad_token_id,
            eos_token_id=self.processor.tokenizer.eos_token_id,
            use_cache=True,
            num_beams=4,
            bad_words_ids=[[self.processor.tokenizer.unk_token_id]],
            return_dict_in_generate=True
        )
        seq = self.processor.tokenizer.batch_decode(outputs.sequences)[0]
        seq = seq.replace(self.processor.tokenizer.eos_token, "").replace(self.processor.tokenizer.pad_token, "")

        # predictions and targets are single strings now
        predictions = [seq]
        targets = [caption[0]]
        val_losses =[]
        val_outputs = self.model(pixel_values, decoder_input_ids=input_ids[:, :-1], labels=labels[:, 1:])
        val_loss = val_outputs.loss
        val_losses.append(val_loss)
        self.log("val_loss", val_loss, on_epoch=True, prog_bar=True, logger=True, batch_size=self.args.valid_batch_size)

        score_list = []
        for pred, target in zip(predictions, targets):
            pred = pred.split("<s_answer>")[1]
            target = target.split("<s_answer>")[1].replace("</s>", "")
            if self.compute_metric(target, pred):
                score_list.append(1)
            else:
                score_list.append(0)
        return {"scores": score_list, "val_loss": torch.stack(val_losses).mean()}

    def validation_epoch_end(self, validation_step_outputs):
        scores_list = [x["scores"] for x in validation_step_outputs]
        val_losses = [x["val_loss"] for x in validation_step_outputs]
        avg_val_loss = torch.stack(val_losses).mean()
        self.log("val_loss", avg_val_loss, on_epoch=True, logger=True, batch_size=self.args.valid_batch_size)

        num_of_loaders = 1
        if num_of_loaders == 1:
            scores_list = [scores_list]
        assert len(scores_list) == num_of_loaders
        cnt = [0] * num_of_loaders
        total_metric = [0] * num_of_loaders
        val_metric = [0] * num_of_loaders
        for i, results in enumerate(scores_list):
            for scores in results:
                cnt[i] += len(scores)
                total_metric[i] += np.sum(scores)
            val_metric[i] = total_metric[i] / cnt[i]
            val_metric_name = f"val_metric_{i}th_dataset"
            self.log_dict({val_metric_name: val_metric[i]}, sync_dist=True)
        self.log_dict({"val_metric": np.sum(total_metric) / np.sum(cnt)}, sync_dist=True)
        print(f"Epoch: {self.current_epoch}, Step: {self.global_step}, Validation Metric: {np.sum(total_metric) / np.sum(cnt):.4f}")

    def configure_optimizers(self):
        max_iter = None

        if int(self.config.get("max_epochs", -1)) > 0:
            assert len(self.config.get("train_batch_sizes")) == 1, "Set max_epochs only if the number of datasets is 1"
            max_iter = (self.config.get("max_epochs") * self.config.get("num_training_samples_per_epoch")) / (
                self.config.get("train_batch_sizes")[0] * torch.cuda.device_count() * self.config.get("num_nodes", 1)
            )

        if int(self.config.get("max_steps", -1)) > 0:
            max_iter = min(self.config.get("max_steps"), max_iter) if max_iter is not None else self.config.get("max_steps")

        assert max_iter is not None
        optimizer = torch.optim.Adam(self.parameters(), lr=self.config.get("lr"))
        scheduler = {
            "scheduler": self.cosine_scheduler(optimizer, max_iter, self.config.get("warmup_steps")),
            "name": "learning_rate",
            "interval": "step",
        }
        return [optimizer], [scheduler]

    @staticmethod
    def cosine_scheduler(optimizer, training_steps, warmup_steps):
        def lr_lambda(current_step):
            if current_step < warmup_steps:
                return current_step / max(1, warmup_steps)
            progress = current_step - warmup_steps
            progress /= max(1, training_steps - warmup_steps)
            return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

        return LambdaLR(optimizer, lr_lambda)

    def train_dataloader(self):
        return DataLoader(self.train_dataset, batch_size=self.args.batch_size, shuffle=True, num_workers=self.args.num_workers)

    def val_dataloader(self):
        return DataLoader(self.val_dataset, batch_size=self.args.valid_batch_size, shuffle=False, num_workers=self.args.num_workers)
    
    @rank_zero_only
    def on_save_checkpoint(self, checkpoint):
        save_path = os.path.join(self.config['result_path'], 'Unichart-checkpoint-epoch='+str(self.current_epoch)+'-'+str(self.global_step))
        self.model.save_pretrained(save_path)
        self.processor.save_pretrained(save_path)

def main():
    parser = argparse.ArgumentParser(description='Fine-tune Vision Encoder Decoder model on VisText dataset')
    parser.add_argument('--train-data-path', type=str, default="/cluster/home/yanc/Unichart/train.json", help='Path to the train.json file')
    parser.add_argument('--valid-data-path', type=str, default="/cluster/home/yanc/Unichart/val.json", help='Path to the valid.json file')
    parser.add_argument('--images-folder', type=str, default="/cluster/home/yanc/Unichart/Chart-to-Alt_All_ThirdFinetune_images", help='Path to the folder containing chart images')
    parser.add_argument('--output_dir', type=str, default="/cluster/home/yanc/Unichart", help='Path to the output directory for saving the checkpoints')
    parser.add_argument('--max_steps', type=int, default=2, help='Max number of training steps')
    parser.add_argument('--batch-size', type=int, default=4, help='Batch Size for training')
    parser.add_argument('--valid-batch-size', type=int, default=4, help='Batch Size for validation')
    parser.add_argument('--max-length', type=int, default=512, help='Max length for decoder generation')
    parser.add_argument('--lr', type=float, default=5e-5, help='Learning rate')
    parser.add_argument('--gpus-num', type=int, default=1, help='Number of GPUs to use')
    parser.add_argument('--num-workers', type=int, default=8, help='Number of workers for DataLoader')
    parser.add_argument('--ckpt-file', type=str, default="ahmed-masry/unichart-base-960", help='Path to the checkpoint file (.ckpt)')
    parser.add_argument('--checkpoint_path', type=str, default = "ahmed-masry/unichart-base-960", help='Path to the checkpoint')
    parser.add_argument('--check-val-every-n-epoch', type=int, default=1, help='Run validation every n epochs')
    parser.add_argument('--log-every-n-steps', type=int, default=500, help='Log every n steps')
    parser.add_argument('--warmup_steps', type=int, default=500, help='Warmup steps')
    parser.add_argument('--nodes-num', type=int, default=1, help='nodes num')
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Using device:", device)

    new_special_tokens = ["<L1_caption>", "<L2L3_caption>"]

    processor = DonutProcessor.from_pretrained(args.checkpoint_path)
    model = VisionEncoderDecoderModel.from_pretrained(args.checkpoint_path)
    processor.tokenizer.add_special_tokens({'additional_special_tokens': new_special_tokens})
    model.decoder.resize_token_embeddings(len(processor.tokenizer))

    train_data_path = "/cluster/home/yanc/Unichart/train.json"
    valid_data_path = "/cluster/home/yanc/Unichart/val.json"

    train_dataset = VisTextDataset(train_data_path, args.images_folder, args.max_length, processor, split="train")
    print(len(train_dataset))

    valid_dataset = VisTextDataset(valid_data_path, args.images_folder, args.max_length, processor, split="valid")
    print(len(valid_dataset))
    wandb_logger = WandbLogger(project="Unichart")

    config = {
        "max_steps": args.max_steps,
        "check_val_every_n_epoch": args.check_val_every_n_epoch,
        "log_every_n_steps": args.log_every_n_steps,
        "lr": args.lr,
        "num_nodes": args.nodes_num,
        "batch_size": args.batch_size,
        "valid_batch_size": args.valid_batch_size,
        "warmup_steps": args.warmup_steps,
        "result_path": args.output_dir,
        "verbose": True
    }
    model_module = VisTextModule(config, processor, model, args, train_dataset, valid_dataset).to(device)
    checkpoint_callback = ModelCheckpoint(dirpath=args.output_dir, save_last=True, save_top_k=-1)
    
    callbacks = [checkpoint_callback]

    if os.path.exists(args.output_dir):
        trainer = pl.Trainer(
            resume_from_checkpoint=os.path.join(args.output_dir, 'last.ckpt'),
            accelerator="gpu",
            devices=args.gpus_num,
            max_epochs=6,
            log_every_n_steps=args.log_every_n_steps,
            num_nodes=args.nodes_num,
            gradient_clip_val=1.0,
            num_sanity_val_steps=0,
            default_root_dir=args.output_dir,
            callbacks=callbacks,
            logger=wandb_logger
        )
    else:
        trainer = pl.Trainer(
            accelerator="gpu",
            devices=args.gpus_num,
            max_epochs=6,
            log_every_n_steps=args.log_every_n_steps,
            num_nodes=args.nodes_num,
            gradient_clip_val=1.0,
            num_sanity_val_steps=0,
            default_root_dir=args.output_dir,
            callbacks=callbacks,
            logger=wandb_logger
        )

    trainer.fit(model_module)

if __name__ == '__main__':
    main()
