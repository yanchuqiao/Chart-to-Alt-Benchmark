from transformers import DonutProcessor, VisionEncoderDecoderModel
from PIL import Image
import torch
import json
import os
import pdb

model_name = "/cluster/home/yanc/Unichart/Finetuning_Chart-to-Alt/Unichart-checkpoint-epoch=4-10065"
model = VisionEncoderDecoderModel.from_pretrained(model_name)
processor = DonutProcessor.from_pretrained(model_name)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

image_folder = "/cluster/home/yanc/Unichart/Chart-to-Alt_All_ThirdFinetune_images"
output_file = "/cluster/home/yanc/Unichart/inference_Unichart_1prompt.txt"
test_data_path = "/cluster/home/yanc/Unichart/test.json"

with open(test_data_path, "r") as fd:
    test_data = json.load(fd)

with open(output_file, "w") as f:
    for item in test_data:
        img_id = item['image_id']
        image_path = os.path.join(image_folder, f"{img_id}")
        
        if os.path.exists(image_path):
            image = Image.open(image_path).convert("RGB")

            pixel_values = processor(image, return_tensors="pt").pixel_values

            input_prompt = "<summarize_chart><s_answer>"
            decoder_input_ids = processor.tokenizer(input_prompt, add_special_tokens=False, return_tensors="pt").input_ids

            outputs = model.generate(
                pixel_values.to(device),
                decoder_input_ids=decoder_input_ids.to(device),
                max_length=model.config.decoder.max_length,
                early_stopping=True,
                pad_token_id=processor.tokenizer.pad_token_id,
                eos_token_id=processor.tokenizer.eos_token_id,
                use_cache=True,
                num_beams=4,
                bad_words_ids=[[processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True,
            )

            generated_sequence = processor.tokenizer.decode(outputs.sequences[0], skip_special_tokens=True)
            generated_sequence = generated_sequence.split('<s_answer> ')[1]

            f.write(f"Generated text for image {img_id}: {generated_sequence}\n")
        else:
            print(f"Image {image_path} not found.")
print("Generated summaries have been saved to", output_file)
